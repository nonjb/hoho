#import <Metal/Metal.h>
#import <MediaPlayer/MediaPlayer.h>
#import <MetalKit/MetalKit.h>
#include <Foundation/Foundation.h>
#include <libgen.h>
#include <mach-o/dyld.h>
#include <mach-o/fat.h>
#include <mach-o/loader.h>
#include <mach/vm_page_size.h>
#include <unistd.h>
#include <array>
#include <deque>
#include <map>
#include <vector>
#include <string>
#include <dispatch/dispatch.h>
#include <execinfo.h>  // Thư viện hỗ trợ stack trace
#include <unordered_set>
#include <signal.h>
#include <limits>


#import "security/oxorany/oxorany_include.h"
#include "va/patch.h"

#import "load/CaptainHook.h"
#import "load/ImGuiDrawView.h"
#import "imgui/imgui.h"
#import "imgui/imgui_impl_metal.h"
#import "imgui/zzz.h"
//Patch library
#import "dobby/NakanoIchika.h"
#import "dobby/NakanoNino.h"
#import "dobby/NakanoMiku.h"
#import "dobby/NakanoYotsuba.h"
#import "dobby/NakanoItsuki.h"
#include "dobby/dobby.h"
#import "dobby/il2cpp.h"


#include "mono/Vector2.h"
#import "mono/Vector3.h"
#include "mono/VInt3.h"
#import "mono/MonoString.h"
#import "fish/hook.h"

#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale
#define patch_NULL(a, b) vm(ENCRYPTOFFSET(a), strtoul(ENCRYPTHEX(b), nullptr, 0))
#define patch(a, b) vm_unity(ENCRYPTOFFSET(a), strtoul(ENCRYPTHEX(b), nullptr, 0))





using namespace IL2CPP;
@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@end

@implementation ImGuiDrawView

static bool autodance;
static bool autobubble;
static int valuedance = 0;
static int perfectRate = 0;
static int valuebubble = 0;
static bool dr;
void *(*get_ParkService_gI)();


std::vector<std::string> log_entries;

void AddLog(const char* fmt, ...) {
    char buf[256];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    log_entries.push_back(std::string(buf));
}

void Hook(uint64_t address, void* replace, void** original) {
    lauthaiHook(address - getASLR("UnityFramework"), replace, original);
}



bool isVibrateEnabled = false; // Trạng thái checkbox

// Hàm rung máy bằng UIImpactFeedbackGenerator (iOS 10+)
void vibrateDevice() {
    if (@available(iOS 10.0, *)) {
        UIImpactFeedbackGenerator *impact = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
        [impact prepare];
        [impact impactOccurred];
    } else {
        // Dùng cách cũ nếu iOS < 10
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    }
}
////////////////////////


static bool MenDeal = true;

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];



    if (!self.device) abort();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

ImGui::StyleColorsClassic();
    
    ImFont* font = io.Fonts->AddFontFromMemoryCompressedTTF((void*)zzz_compressed_data, zzz_compressed_size, 60.0f, NULL, io.Fonts->GetGlyphRangesVietnamese());
    
    ImGui_ImplMetal_Init(_device);

    return self;
}


+ (void)showChange:(BOOL)open
{
    MenDeal = open;
}



- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}

- (void)loadView
{

 

    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;




}

//hao


#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

#pragma mark - MTKViewDelegate

- (void)drawInMTKView:(MTKView*)view
{
   
    
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.scale ?: UIScreen.mainScreen.scale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 120);
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
   
    
        
        if (MenDeal == true) {
            [self.view setUserInteractionEnabled:YES];
        } else if (MenDeal == false) {
            [self.view setUserInteractionEnabled:NO];
        }

    void Il2CppAttachOld();
    Il2CppAttachOld();

        MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
        if (renderPassDescriptor != nil)
        {
            id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
            [renderEncoder pushDebugGroup:@"ImGui Jane"];

           

ImGui_ImplMetal_NewFrame(renderPassDescriptor);
            ImGui::NewFrame();
            
            ImFont* font = ImGui::GetFont();
            font->Scale = 16.f / font->FontSize;
            
            CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 360) / 2;
            CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 300) / 2;
            
            ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
            ImGui::SetNextWindowSize(ImVec2(0, 0), ImGuiCond_FirstUseEver);
  


    Il2CppMethod methodAccess("Assembly-CSharp.dll");


   uint64_t offgetnext = methodAccess.getClass("", "DanceScr").getMethod("GetNextAnimAndKeyDance", 1);

 uint64_t offPlantTree = methodAccess.getClass("", "FarmService").getMethod("plantTree", 2);


 uint64_t offHarvestTree = methodAccess.getClass("", "FarmService").getMethod("harvestTree", 1);



uint64_t off_doStateBubble = methodAccess.getClass("", "DanceService").getMethod("doStateBubble", 4);

uint64_t off_doState = methodAccess.getClass("", "DanceService").getMethod("doState", 3);


    uint64_t offdoChatPublic = methodAccess.getClass("", "GlobalService").getMethod("doChatPublic", 2);


            
uint64_t off_setInteract = methodAccess.getClass("", "ParkService").getMethod("setInteract", 9);


uint64_t offAddActionDynamic = methodAccess
    .getClass("", "MenuChar")
    .getMethod("addActionDynamic", 2);

uint64_t off_gI = methodAccess.getClass("", "ParkService").getMethod("gI", 0);

//QQ


    lauthaiHook(off_gI, hook_ParkService_gI, orig_ParkService_gI);
    lauthaiHook(off_doStateBubble, _doStateBubble, doStateBubble);
    lauthaiHook(off_doState, _doState, doState);
    lauthaiHook(offdoChatPublic, old_doChatPublic, doChatPublic);

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    lauthaiHook(off_setInteract, _setInteract, setInteract);
    lauthaiHook(offAddActionDynamic, _addActionDynamic, addActionDynamic);
    lauthaiHook(offgetnext, _DanceA, DanceA);
    lauthaiHook(offPlantTree, _plantTree, plantTree);
    lauthaiHook(offHarvestTree, _harvestTree, harvestTree);
});



            
            
if (MenDeal == true)
            {                
                ImGui::Begin("AM2 | @lauthaii", &MenDeal, ImGuiWindowFlags_AlwaysAutoResize);

#define lauthaiSlider(label, var, min, max, lu) \
    ImGui::PushItemWidth(100);                 \
    ImGui::SliderInt(label, var, min, max, lu);\
    ImGui::PopItemWidth();


if (ImGui::BeginTabBar("MainTabBar"))  
                {
if (ImGui::BeginTabItem("/Lệnh"))
                    {   
    ImGui::Text("/th -> Thu hoạch cây");
    ImGui::Text("/tc [id_cây] -> Trồng cây theo ID");
ImGui::Separator();
    ImGui::Text("/onauto -> Bật auto hành động");
    ImGui::Text("/offauto -> Tắt auto hành động");
    ImGui::Text("/settime:[giây] -> Cài delay mỗi lần hành động");
    ImGui::Text("/@zz:[id] -> Cài id hành động lên người khác");



         

ImGui::EndTabItem();
}
                    if (ImGui::BeginTabItem("Nhảy"))
                    {
                
                ImGui::TableNextColumn();

                if (ImGui::Checkbox("Auto 4K", &autodance)) {
vibrateDevice();
}

lauthaiSlider("Cài % Perfect", &perfectRate, 0, 100, "%d%%");
               

ImGui::EndTabItem();
}


if (ImGui::BeginTabItem("Chat"))

                {            

    if (ImGui::Checkbox("Auto Chat", &spamChat)) {
vibrateDevice();
        if (!spamChat) {
            stopSpam(); // Tắt spam ngay khi checkbox bị tắt
        }
    }
        
lauthaiSlider("delay time", &spamDelay, 1, 20, "%ds");

    // Slider chỉnh số lần spam
lauthaiSlider("count", &spamCount, 1, 500, "%dx");


ImGui::EndTabItem();

}



ImGui::EndTabBar();
}
               

                ImGui::End();
                
                
                
                
            }
            ImDrawList* draw_list = ImGui::GetBackgroundDrawList();


                  ImGuiStyle& style = ImGui::GetStyle();
            ImVec4* colors = style.Colors;
            style.WindowRounding = 10.000f;
            style.WindowTitleAlign = ImVec2(0.490f, 0.520f); 
            
            style.ButtonTextAlign = ImVec2(0.510f, 0.490f);
            
// Bo góc cửa sổ và tab
style.WindowRounding = 10.0f;

// Hiệu ứng hover mượt
style.Alpha = 0.80f;
style.ItemSpacing = ImVec2(10, 8);
style.ScrollbarSize = 12.0f;

style.FrameRounding = 2.0f;
style.ScrollbarRounding = 2.0f;
style.GrabRounding = 2.0f;

// Màu nền cửa sổ (trắng)
// Màu nền cửa sổ (xám macOS)
colors[ImGuiCol_WindowBg] = ImVec4(0.95f, 0.95f, 0.95f, 1.0f);

// Màu viền cửa sổ (xám nhạt hơn)
colors[ImGuiCol_Border] = ImVec4(0.8f, 0.8f, 0.8f, 1.0f);

// Màu tiêu đề cửa sổ (xám macOS)
colors[ImGuiCol_TitleBg] = ImVec4(0.85f, 0.85f, 0.85f, 1.0f);
colors[ImGuiCol_TitleBgActive] = ImVec4(0.85f, 0.85f, 0.85f, 1.0f);
colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.85f, 0.85f, 0.85f, 1.0f);

// Màu button/tab (xám nhẹ)
colors[ImGuiCol_Button] = ImVec4(0.88f, 0.88f, 0.88f, 1.0f);
colors[ImGuiCol_ButtonHovered] = ImVec4(0.75f, 0.75f, 0.75f, 1.0f);
colors[ImGuiCol_ButtonActive] = ImVec4(0.65f, 0.65f, 0.65f, 1.0f);

colors[ImGuiCol_Tab] = ImVec4(0.88f, 0.88f, 0.88f, 1.0f);
colors[ImGuiCol_TabHovered] = ImVec4(0.75f, 0.75f, 0.75f, 1.0f);
colors[ImGuiCol_TabActive] = ImVec4(0.65f, 0.65f, 0.65f, 1.0f);

// Màu slider (xám đậm hơn)
colors[ImGuiCol_SliderGrab] = ImVec4(0.55f, 0.55f, 0.55f, 1.0f);
colors[ImGuiCol_SliderGrabActive] = ImVec4(0.45f, 0.45f, 0.45f, 1.0f);

// Màu checkbox (xám trung tính)
colors[ImGuiCol_CheckMark] = ImVec4(0.4f, 0.4f, 0.4f, 1.0f);

// Màu text (xám đậm gần đen)
colors[ImGuiCol_Text] = ImVec4(0.1f, 0.1f, 0.1f, 1.0f);

// Màu resize grip (giống macOS)
colors[ImGuiCol_ResizeGrip] = ImVec4(0.75f, 0.75f, 0.75f, 1.0f);
colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.65f, 0.65f, 0.65f, 1.0f);
colors[ImGuiCol_ResizeGripActive] = ImVec4(0.55f, 0.55f, 0.55f, 1.0f);

// Màu sắc scrollbar giống macOS
style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.94f, 0.94f, 0.94f, 0.60f);         // Màu nền của scrollbar (xám nhạt, mờ nhẹ)
style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.80f, 0.80f, 0.80f, 0.80f);         // Màu phần cuộn của scrollbar (xám sáng, mờ nhẹ)
style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.65f, 0.65f, 0.65f, 1.00f);  // Màu khi hover (xám tối hơn)
style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);   // Màu khi kéo (xám đậm)


            ImGui::Render();
            ImDrawData* draw_data = ImGui::GetDrawData();
            ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
          
            [renderEncoder popDebugGroup];
            [renderEncoder endEncoding];

            [commandBuffer presentDrawable:view.currentDrawable];
        }

        [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}




int (*_DanceA)(void *instance, int dieunhay);
int DanceA(void *instance, int dieunhay) {
    if (autodance) { 
        int randomValue = rand() % 100;

        if (randomValue < perfectRate) {
            
            dieunhay = 0; // Perfect
        } else {

            dieunhay= 1;


        }

        AddLog("[Hook] DanceA() - Auto Dance Enabled (Rate: %d%%) -> Result: %d\n", perfectRate, dieunhay);
    }

    return _DanceA(instance, dieunhay);
}


void* zz;
float xx;

void (*_update)(void* instance);
void update(void* instance){

_update(instance);

}


////////AUTO FARM
void (*_plantTree)(void* instance, signed char IDCell, signed char idTree);
void (*_harvestTree)(void* instance, signed char IDCell);

void plantTree(void* instance, signed char IDCell, signed char idTree) {
   
        _plantTree(instance, IDCell, idTree);
        
}

void harvestTree(void* instance, signed char IDCell) {

_harvestTree(instance, IDCell);

}


void doThuHoach(void* instance) {

    if (instance != NULL) {
for (int i = 0; i <= 100; ++i) {

      
                  _harvestTree(instance, i);


                                
        }
    }
}

void doTrongCay(void* instance, signed char treeID) {
if (instance != NULL) {

for (int i = 0; i <= 100; i++) {

                            _plantTree(instance, i, treeID); 
                                                    
               
}
}
}






static bool spamChat = false;
static int spamDelay = 1;  // Thời gian delay mặc định (giây)
static int spamCount = 1;  // Số lần spam mặc định
static dispatch_source_t spamTimer = NULL; // Timer quản lý spam

// Hàm lấy nội dung tin nhắn từ MonoString
std::string getMessageText(MonoString* monoString) {
    if (!monoString) return "";
    return monoString->toString();
}

// Hàm hủy spam nếu đang chạy
void stopSpam() {
    if (spamTimer) {
        dispatch_source_cancel(spamTimer);
        spamTimer = NULL;
        
    }
}

// Hàm auto spam
void startSpam(void* instance, MonoString* message, MonoString* m) {
    if (!spamChat || spamCount <= 0 || spamDelay < 0) {
        stopSpam();
        return;
    }

    // Hủy spam cũ nếu có
    stopSpam();


    spamTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(spamTimer, dispatch_time(DISPATCH_TIME_NOW, 0), spamDelay * NSEC_PER_SEC, 0);
    
    __block int count = 0; // Fix lỗi biến không thay đổi trong block

    dispatch_source_set_event_handler(spamTimer, ^{
        if (!spamChat || count >= spamCount) {
            stopSpam();
            return;
        }

        old_doChatPublic(instance, message, m);
        count++;
        
    });

    dispatch_resume(spamTimer);
}

// Hook doChatPublic
void (*old_doChatPublic)(void* instance, MonoString* message, MonoString* m);
void doChatPublic(void* instance, MonoString* message, MonoString* m) {
    if (!instance || !message) return;

    std::string msgText = getMessageText(message);
    AddLog("[HOOK] Message Sent: %s\n", msgText.c_str());

    if (spamChat) {
        startSpam(instance, message, m);
        return; // Không gửi tin nhắn lên server khi đang spam
    }

if (msgText == "/th") {
       doThuHoach(instance);
        return;
    }

    // Nếu chat "/tc <id>" → Trồng cây theo ID
    if (msgText.find("/tc:") == 0) {
        int treeID = atoi(msgText.substr(4).c_str());
     doTrongCay(instance, treeID);
        return;
    }


if (msgText == "/onauto") {
    autoPem = true;
    AddLog("[LỆNH] Auto Pem: BẬT");
    if (targetPlayerID != -1) attackTarget();
    return;
}

if (msgText == "/offauto") {
    autoPem = false;
    AddLog("[LỆNH] Auto Pem: TẮT");
    return;
}

if (msgText.find("/settime:") == 0) {
    float sec = atof(msgText.substr(9).c_str());
        attackDelaySec = sec;
        AddLog("[LỆNH] Delay tấn công = %.2f giây", attackDelaySec);
    
    return;
}

if (msgText.find("/@zz:") == 0) {
    int act = atoi(msgText.substr(5).c_str());
    actionType = act;
    AddLog("[LỆNH] Đặt actionType = %d", actionType);
    return;
}

    old_doChatPublic(instance, message, m);
}



/////////



//change skin



void (*_doStateBubble)(void* instance, int8_t state, int16_t nhip, void* bubble, int16_t listKeyPress);
void doStateBubble(void* instance, int8_t state, int16_t nhip, void* bubble, int16_t listKeyPress) {

//AddLog("state: %d, nhip: %d, list: %d", state, nhip, listKeyPress);
      if (instance != NULL && autobubble) {

 state = 0;

        
    }
        
    _doStateBubble(instance, state, nhip, bubble, listKeyPress);
}




std::vector<int16_t> danceKeys; // Danh sách phím cần nhấn

void (*_doState)(void* instance, int8_t state, int16_t nhip, int8_t* listKeyPress);
void doState(void* instance, int8_t state, int16_t nhip, int8_t* listKeyPress) {

      if (instance != NULL && autodance) {

state = 0;
        
    
          
  }
        
    _doState(instance, state, nhip, listKeyPress);
}

void *(*orig_ParkService_gI)();



void *hook_ParkService_gI() {
    AddLog("[HOOK] ParkService.gI() called");
    void *ret = orig_ParkService_gI();
    AddLog("[HOOK] ParkService.gI() returns %p", ret);
    return ret;
}




static int32_t targetPlayerID = -1;       
static int actionType = -1;// ID mục tiêu (-1 = không có mục tiêu)
static bool autoPem = false;              // Biến kiểm soát chế độ tự động tấn công
static float attackDelaySec = 1.0f;  // mặc định 1 giây

void (*_addActionDynamic)(void* instance, int idPlayer, void* list);
void addActionDynamic(void* instance, int idPlayer, void* list) {
    targetPlayerID = idPlayer;
    AddLog("[HOOK] Đã lưu ID từ menu hành động: %d", idPlayer);

    _addActionDynamic(instance, idPlayer, list);

    
}

void (*_setInteract)(void* instance, int8_t type, int32_t id2, int16_t idAction,
                     Vector3 pos2, int32_t angle2, int8_t time, int16_t curAct,
                     Vector3 pos1, int32_t angle1);
void setInteract(void* instance, int8_t type, int32_t id2, int16_t idAction, Vector3 pos2, int32_t angle2, int8_t time, int16_t curAct, Vector3 pos1, int32_t angle1) {
    _setInteract(instance, type, id2, idAction, pos2, angle2, time, curAct, pos1, angle1);
}

int8_t type;
void attackTarget() {
    if (!autoPem || targetPlayerID == -1) return;

    void* parkInstance = orig_ParkService_gI();
    if (!parkInstance) {
        AddLog("ParkService.gI() NULL!");
        return;
    }

    AddLog("[AUTO ATTACK] Tấn công ID: %d (Delay: %.1fs)", targetPlayerID, attackDelaySec);

    _setInteract(parkInstance, type, targetPlayerID, actionType,
                 Vector3(0.0f, 0.0f, 0.0f), 0,
                 0, 0,
                 Vector3(0.0f, 0.0f, 0.0f), 0);

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(attackDelaySec * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        attackTarget();
    });
}






@end

