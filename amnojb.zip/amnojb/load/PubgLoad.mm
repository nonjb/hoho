//  PubgLoad.m
#import "PubgLoad.h"
#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import "JHPP.h"
#import "JHDragView.h"
#import "ImGuiLoad.h"
#import "ImGuiDrawView.h"

@interface PubgLoad()
@property (nonatomic, strong) ImGuiDrawView *vna;
@property (nonatomic, strong) UIImageView *avatarView;
@property (nonatomic, strong) UIView *dragView;
@property (nonatomic, assign) BOOL isVibrateEnabled;
@property (nonatomic, assign) BOOL isMenuVisible;
@property (nonatomic, strong) UILabel *lauthaiOverlay; // Thêm khai báo thuộc tính này
@end

@implementation PubgLoad

static PubgLoad *extraInfo;

+ (void)load {
    [super load];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        extraInfo = [PubgLoad new];
        [extraInfo setupLauthaiOverlay];
    });
}

// Tạo UI hiển thị lauthaiOverlay
- (void)setupLauthaiOverlay {
    UIWindow *mainWindow = [UIApplication sharedApplication].keyWindow;
    CGRect screenBounds = [UIScreen mainScreen].bounds;
    
    // Kích thước UI
    CGFloat width = 70;
    CGFloat height = 30;
    
    // Vị trí ban đầu: góc trên bên trái nhưng không sát mép
    CGFloat startX = MAX(10, screenBounds.size.width * 0.05);
    CGFloat startY = MAX(50, screenBounds.size.height * 0.1);

    self.dragView = [[UIView alloc] initWithFrame:CGRectMake(startX, startY, width, height)];
    self.dragView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
    self.dragView.layer.borderWidth = 1;
    self.dragView.layer.borderColor = [[UIColor blackColor] CGColor];
    self.dragView.layer.cornerRadius = 15;
    self.dragView.layer.masksToBounds = YES;
    self.dragView.userInteractionEnabled = YES;

    // Avatar nhỏ hơn
    self.avatarView = [[UIImageView alloc] initWithFrame:CGRectMake(4, 3, 24, 24)];
    self.avatarView.layer.cornerRadius = 11;
    self.avatarView.layer.borderWidth = 1;
    self.avatarView.layer.borderColor = [[UIColor blackColor] CGColor];
    self.avatarView.layer.masksToBounds = YES;
    self.avatarView.contentMode = UIViewContentModeScaleAspectFill;
    [self loadAvatarFromURL:@"https://is3-ssl.mzstatic.com/image/thumb/Purple112/v4/b4/0f/29/b40f29e5-572a-be77-8c83-2e689fb30346/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/146x0w.webp"];

    // lauthaiOverlay Label nhỏ hơn với màu xanh lá
    self.lauthaiOverlay = [[UILabel alloc] initWithFrame:CGRectMake(33, 6, 70, 18)];
    self.lauthaiOverlay.textColor = [UIColor cyanColor]; // Màu xanh lá nhạt (#89ff7c)
    self.lauthaiOverlay.font = [UIFont boldSystemFontOfSize:11]; // Giảm kích thước chữ
    self.lauthaiOverlay.textAlignment = NSTextAlignmentLeft;
[self updateBatteryPercentage];
    
    // Bóng chữ nhẹ
    self.lauthaiOverlay.layer.shadowColor = [[UIColor blackColor] CGColor];
    self.lauthaiOverlay.layer.shadowOffset = CGSizeMake(0.5, 0.5);
    self.lauthaiOverlay.layer.shadowOpacity = 0.5;
    self.lauthaiOverlay.layer.shadowRadius = 1.0;

    // Thêm vào View
    [self.dragView addSubview:self.avatarView];
    [self.dragView addSubview:self.lauthaiOverlay];
    [mainWindow addSubview:self.dragView];

    // Gesture kéo thả
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
    [self.dragView addGestureRecognizer:panGesture];

    // Gesture nhấn để mở/tắt menu
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toggleMenu)];
    [self.dragView addGestureRecognizer:tapGesture];

    self.isVibrateEnabled = YES;
    self.isMenuVisible = NO;

[[NSNotificationCenter defaultCenter] addObserver:self
                                         selector:@selector(updateBatteryPercentage)
                                             name:UIDeviceBatteryLevelDidChangeNotification
                                           object:nil];

[[NSNotificationCenter defaultCenter] addObserver:self
                                         selector:@selector(updateBatteryPercentage)
                                             name:UIDeviceBatteryStateDidChangeNotification
                                           object:nil];

}

// Nhấn để mở/tắt menu + rung
- (void)toggleMenu {
    if (self.isMenuVisible) {
        [self.vna.view removeFromSuperview];
        self.isMenuVisible = NO;
        
    } else {
        if (!_vna) {
            _vna = [[ImGuiDrawView alloc] init];
        }
        [ImGuiDrawView showChange:YES];
        [[UIApplication sharedApplication].keyWindow.rootViewController.view addSubview:_vna.view];
        self.isMenuVisible = YES;
            }

    if (self.isVibrateEnabled) {
        [self vibrateDevice];
    }
}

- (void)updateBatteryPercentage {
    UIDevice *device = [UIDevice currentDevice];
    device.batteryMonitoringEnabled = YES;
    float batteryLevel = device.batteryLevel;

    if (batteryLevel < 0.0f) {
        self.lauthaiOverlay.text = @"--%";
    } else {
        int percentage = (int)(batteryLevel * 100);
        self.lauthaiOverlay.text = [NSString stringWithFormat:@"%d%%", percentage];
    }
}


- (void)loadAvatarFromURL:(NSString *)urlString {
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) return;

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSData *imageData = [NSData dataWithContentsOfURL:url];
        if (imageData) {
            UIImage *image = [UIImage imageWithData:imageData];
            dispatch_async(dispatch_get_main_queue(), ^{
                self.avatarView.image = image ?: [UIImage imageNamed:@"default_avatar"];
            });
        }
    });
}

// Kéo thả vị trí UI
- (void)handlePanGesture:(UIPanGestureRecognizer *)gesture {
    CGPoint translation = [gesture translationInView:self.dragView.superview];
    CGPoint newCenter = CGPointMake(self.dragView.center.x + translation.x, self.dragView.center.y + translation.y);
    
    // Lấy kích thước màn hình
    CGRect screenBounds = [UIScreen mainScreen].bounds;
    CGFloat halfWidth = self.dragView.bounds.size.width / 2;
    CGFloat halfHeight = self.dragView.bounds.size.height / 2;

    // Giới hạn trong màn hình
    newCenter.x = MAX(halfWidth, MIN(screenBounds.size.width - halfWidth, newCenter.x));
    newCenter.y = MAX(halfHeight, MIN(screenBounds.size.height - halfHeight, newCenter.y));

    self.dragView.center = newCenter;
    [gesture setTranslation:CGPointZero inView:self.dragView.superview];
}


// Hàm rung máy
- (void)vibrateDevice {
    if (@available(iOS 10.0, *)) {
        UIImpactFeedbackGenerator *impact = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
        [impact prepare];
        [impact impactOccurred];
    } else {
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    }
}

@end
